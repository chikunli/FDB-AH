## Quick Start for "A Stability Framework for Parameter Selection in the Minimum Covariance Determinant Problem"

### Simulated Data
```R
library(StableMCD)

# Regular Outliers
n = 1000
x1 = rnorm(n)
x1[1:(n * 0.2)] = rnorm(n * 0.2, 10)
x2 = rnorm(n)
x = cbind(x1,x2)

result = bootstrap_mcd(x,seq(0.5,0.975,by=0.025),B=50,classifier="MD")
plot(seq(0.5,0.975,by=0.025), result$iim, type = "b")

# Masking outliers
n = 1000
x1 = rnorm(n)
x1[1:(n * 0.15)] = rnorm(n * 0.15, 7)
x1[(n * 0.15 + 1):(n * 0.15 + n * 0.05)] = rnorm(n * 0.05, 10^3)
x2 = rnorm(n)
x = cbind(x1,x2)

result = bootstrap_mcd(x,seq(0.5,0.975,by=0.025),B=50,classifier="MD")
plot(seq(0.5,0.975,by=0.025), result$iim, type = "b")

# Example 1
set.seed(1234)
n = 1000
x1 = rnorm(n)
x2 = rnorm(n)

x = cbind(x1, x2)#

x[1, ] = c(10, 10)
x[2:200, ] = 20 + rnorm(prod(dim(x[2:200, ])))

dvals = seq(0.7,0.9,by=0.001)
result = bootstrap_mcd(x,dvals,B=50,classifier="MD")
plot(dvals, result$iim, type = "b", main = "example 1 - minimum at 0.766")

# Example 2
set.seed(1234)
n = 1000
x1 = rnorm(n)
x2 = rnorm(n)

x = cbind(x1, x2)#

x[1:5, ] = rep(c(-10, 10), each = 5) + rnorm(10)
x[6, ] = 20


dvals = seq(0.9,0.999,by=0.001)
result = bootstrap_mcd(x,dvals,B=50,classifier="MD")
plot(dvals, result$iim, type = "b", main = "example 2 - minimum at 0.991")


# Example 3
set.seed(1234)
n = 1000
x1 = rnorm(n)
x2 = rnorm(n)

x = cbind(x1, x2)#

x[1, ] = c(10, 10)
x[2:3, ] = -20


dvals = seq(0.9,0.999,by=0.001)
result = bootstrap_mcd(x,dvals,B=50,classifier="MD")
plot(dvals, result$iim, type = "b", main = "example 3 - minimum at 0.995") 
```
