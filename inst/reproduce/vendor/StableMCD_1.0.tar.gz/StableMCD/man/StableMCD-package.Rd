\name{StableMCD-package}
\alias{StableMCD-package}
\alias{StableMCD}
\docType{package}
\title{
\packageTitle{StableMCD}
}
\description{
\packageDescription{StableMCD}
}
\details{
%%  ~~ An overview of how to use the package, ~~
%%  ~~ including the most important functions ~~
}
\author{
\packageAuthor{StableMCD}

Maintainer: \packageMaintainer{StableMCD}
}
\references{
%%  ~~ Literature or other references for background information ~~
}
\keyword{package}

%% Uncomment below to imitate parts of library(help = StableMCD)
%\section{The \file{DESCRIPTION} File}{\packageDESCRIPTION{StableMCD}}
%\section{Documentation Index}{\packageIndices{StableMCD}}

\seealso{
%%  ~~ Optional links to other man pages, e.g. ~~
%%  ~~ \code{\link[<pkg>:<pkg>-package]{<pkg>}} ~~
}
\examples{
%%  ~~ Optional simple examples of the most important functions ~~
}
